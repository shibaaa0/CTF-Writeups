def verify_ctfd_token(ctfd_token):
    pass